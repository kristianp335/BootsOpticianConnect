// Boots Contract Dropzone Fragment JavaScript
// Simple dropzone container - no additional logic required